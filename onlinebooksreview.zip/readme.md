### Installation Introduction

1. Clone the repo `git@gitlab.com:Mashpy/servereditor_web.git`
2. `composer install`
3. Create `.env` file (`.env.example` included)
4. `php artisan key:generate`
5. `php artisan migrate`