

<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="alert alert-info">
			<center>Welcome to Dashboard</center>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>