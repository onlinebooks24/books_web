

<?php $__env->startSection('title'); ?>
  <?php echo e($categoryName); ?> | OnlineBooksReview
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container">
  <div class="row">
      <div class="col-md-8"> 
         <?php if(!empty(Request::Segment(1))): ?>
            <div class="alert alert-info">
              <strong>Category : </strong> <?php echo e($categoryName); ?> . Show All Posts.
            </div>
         <?php endif; ?>
         <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <h1>
                  <a href="<?php echo e(route('post.single' , [ 'category_name' => $post->category->name , 'slug' => $post->slug ])); ?>"><?php echo e($post->title); ?></a>
              </h1>
              <p><span class="glyphicon glyphicon-time"></span> Posted on <?php echo e($post->created_at->format('m-d-Y')); ?>  by <span style="color: blue;text-transform: capitalize;"><?php echo e($post->user->name); ?></span></p>
              <!-- <hr>
              <img class="img-responsive" src="http://placehold.it/900x300" alt=""> -->
              <hr>
              <p><?php echo str_limit($post->body,400); ?></p> 
              <a class="btn btn-primary" href="<?php echo e(route('post.single' , [ 'category_name' => $post->category->name , 'slug' => $post->slug ])); ?>" style="float: right;">Read More <span class="glyphicon glyphicon-chevron-right"></span></a>
              <div class="clearfix"></div>
              <hr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         
      <section>
        <nav>
          <ul class="pager">
              <?php if($posts->currentPage() !== 1): ?>
                <li class="previous"><a href="<?php echo e($posts->previousPageUrl()); ?>"><span aria-hidden="true">&larr;</span> Older</a></li>
              <?php endif; ?>
              <?php if($posts->currentPage() !== $posts->lastPage() && $posts->hasPages()): ?>
                <li class="next"><a href="<?php echo e($posts->nextPageUrl()); ?>">Newer <span aria-hidden="true">&rarr;</span></a></li>
              <?php endif; ?>
          </ul>
        </nav>
        </section>   

      </div>

      <?php echo $__env->make('includes.left_sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
      <?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>