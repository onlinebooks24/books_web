<!Doctype html>
<html class="no-js" lang="">

<head>
  <meta charset="utf-8">
  <title><?php echo $__env->yieldContent('title'); ?></title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width">
  <link rel="shortcut icon" href="/favicon.ico">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
  


    <?php echo $__env->yieldContent('run_custom_css_file'); ?>
    <?php echo $__env->yieldContent('run_custom_css'); ?>
</head>
	<body>	

    <?php echo $__env->yieldContent('content'); ?>

    <script type="text/javascript" src="<?php echo e(asset('js/jquery-2.1.4.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>  

    <?php echo $__env->yieldContent('run_custom_js_file'); ?>
    <?php echo $__env->yieldContent('run_custom_jquery'); ?>
	</body>
</html>
