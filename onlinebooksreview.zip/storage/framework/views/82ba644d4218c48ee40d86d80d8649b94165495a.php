
</div> <!--row -->
<hr>
<!-- Footer -->
<footer>
    <div class="row">
        <div class="col-lg-12" style="text-align: center;padding: 20px">
            <p>© 2017 <a href="#"><b style="color: #87B832">ServerEditor</b></a>, All Rights Reserved.</p>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
</footer>