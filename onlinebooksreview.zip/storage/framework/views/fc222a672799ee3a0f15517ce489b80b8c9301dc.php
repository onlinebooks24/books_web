<?php $__env->startSection('run_custom_css_file'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('summernote/summernote.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="alert alert-info">
            <strong>Update Post</strong>
        </div>
    </div>
    <div class="row">
        <?php if(Session::has('success')): ?>
            <div class="alert alert-warning">
                <?php echo e(Session::get('success')); ?>

            </div>
        <?php endif; ?>
        <?php if(count($errors) > 0): ?>
            <ul class="alert alert-danger">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($error); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>
    </div>
    <div class="row">
        <div class="alert alert-success">
            <form action="<?php echo e(route('post.update' , $post->id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <input name="_method" type="hidden" value="PUT">
                <div class="form-group"> <!-- Name field -->
                    <label class="control-label " for="name">Title</label>
                    <input class="form-control" name="title" type="text" value="<?php echo e($post->title); ?>" />
                </div>

                <div class="form-group">
                    <label class="control-label">Select Category</label>
                    <select class="form-control" name="category_id">
                        <option value="">Select Category</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>" <?php echo e($post->category_id == $category->id ? 'selected'  : ''); ?> > <?php echo e($category->name); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group"> <!-- Message field -->
                    <label class="control-label " for="message">Message</label>
                    <textarea class="form-control" id="summernote" name="body"><?php echo $post->body; ?></textarea>
                </div>

                <div class="form-group">
                    <button type="submit" class="btn btn-warning btn-lg" style="width: 100%;"><span class="glyphicon glyphicon-ok-sign"></span> Update</button>
                </div>

            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('run_custom_js_file'); ?>
    <script type="text/javascript" src="<?php echo e(asset('summernote/summernote.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('run_custom_jquery'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#summernote').summernote({
                height : '300px',
                placeholder : 'Content here...........'
            });


            $('#clear').on('click' , function(){
                $('#summernote').summernote('code', null);
            });


        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>