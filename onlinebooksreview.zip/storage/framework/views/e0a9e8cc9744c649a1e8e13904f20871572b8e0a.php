<!Doctype html>
<html class="no-js" lang="">

<head>
  <meta charset="utf-8">
  <title><?php echo $__env->yieldContent('title'); ?></title>
  <meta name="description" content="Servereditor is a powerful and lightweight linux based hosting control panal which helps you automated and easily maintanence of Dedicated & VPS servers without using ssh console">
  <meta name="viewport" content="width=device-width">
  <meta property="og:locale" content="en_US" />
  <meta property="og:type" content="website" />
  <meta property="og:site_name" content="www.servereditor.com" />
  <meta property="og:image" content="<?php echo e(asset('images/servereditor_thumb_logo.png')); ?>" />
  <link rel="shortcut icon" href="/favicon.ico">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
    <?php echo $__env->yieldContent('run_custom_css_file'); ?>
    <?php echo $__env->yieldContent('run_custom_css'); ?>
</head>
	<body>	

    <?php echo $__env->yieldContent('content'); ?>

    <script type="text/javascript" src="<?php echo e(asset('js/jquery-2.1.4.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>

    <script>
      (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
      (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
      m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
      })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

      ga('create', 'UA-96612278-1', 'auto');
      ga('send', 'pageview');

    </script>

    <?php echo $__env->yieldContent('run_custom_js_file'); ?>
    <?php echo $__env->yieldContent('run_custom_jquery'); ?>
	</body>
</html>
