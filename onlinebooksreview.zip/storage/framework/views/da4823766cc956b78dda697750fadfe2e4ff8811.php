<?php $__env->startSection('title'); ?>
<?php echo e($post->title); ?> | OnlineBooksReview
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8">
           <div class="well">
               <h1>
                 <?php echo e($post->title); ?>

               </h1>
               <p><span class="glyphicon glyphicon-time"></span> Posted on <?php echo e($post->created_at->format('m-d-Y')); ?>  by <span style="color: blue;text-transform: capitalize;"><?php echo e($post->author); ?></span></p>
               <!-- <hr>
               <img class="img-responsive" src="http://placehold.it/900x300" alt=""> -->
               <hr>
               <p><?php echo $post->body; ?></p>
           </div>

        
        <div class="fb-comments" data-href=" <?php echo('http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']); ?>" data-width="100%" data-numposts="5"></div>

        <div id="fb-root"></div>
        <script>
        (function(d, s, id) {
          var js, fjs = d.getElementsByTagName(s)[0];
          if (d.getElementById(id)) return;
          js = d.createElement(s); js.id = id;
          js.src = "//connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v2.8&appId=935252503278915";
          fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));
        </script>

        </div>
        
    <?php echo $__env->make('includes.left_sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
    <?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>