<?php $__env->startSection('content'); ?>
 <div class="row">
 	<div class="alert alert-info">
 		<strong>View All Category</strong>
 	</div>
 </div>
 <div class="row">
 	<?php if(Session::has('success')): ?>
	    <div class="alert alert-warning">
	      <?php echo e(Session::get('success')); ?>

	    </div>
	 <?php endif; ?>
	 <?php if(count($errors) > 0): ?>
		<ul class="alert alert-danger">
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php echo e($error); ?>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	<?php endif; ?>
 </div>
 <div class="row alert alert-success">
    <div class="col-md-6">
    <div class="table-responsive">         
	  <table id="mytable" class="table table-bordred table-striped">    
       <thead>
       
       <th>Category Name</th>
       <th>Edit</th>
       <th>Delete</th>
       </thead>
    <tbody>
    <?php  
    	$i = 0;
     ?>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td><?php echo e($category->name); ?></td>
    <td><p data-placement="top" data-toggle="tooltip" title="Edit"><button class="btn btn-primary btn-xs" data-title="Edit" data-toggle="modal" data-target="#edit<?php echo $i ; ?>" ><span class="glyphicon glyphicon-pencil"></span></button></p></td>
    <td><p data-placement="top" data-toggle="tooltip" title="Delete"><button class="btn btn-danger btn-xs" data-title="Delete" data-toggle="modal" data-target="#delete<?php echo  $i ; ?>" ><span class="glyphicon glyphicon-trash"></span></button></p></td>
    </tr>
     
	<div class="modal fade" id="edit<?php echo $i; ?>" tabindex="-1" role="dialog" aria-labelledby="edit" aria-hidden="true">
	  <div class="modal-dialog">
		<div class="modal-content">
		<form action="<?php echo e(route('category.update' , $category->id)); ?>" method="post" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <input name="_method" type="hidden" value="PUT">
		   <div class="modal-header">
		    <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>
		    <h4 class="modal-title custom_align" id="Heading">Edit Category Name</h4>
		  </div>
		    <div class="modal-body">
		      <div class="form-group">
		    	<input class="form-control " type="text" name="name" value="<?php echo e($category->name); ?>" >
		    </div>
		  </div>
		   <div class="modal-footer ">
		    <button type="submit" class="btn btn-warning btn-lg" style="width: 100%;"><span class="glyphicon glyphicon-ok-sign"></span> Update</button>
		  </div>
		  </form>
		 </div>
		<!-- /.modal-content --> 
		</div>
	  <!-- /.modal-dialog --> 
	</div>
    
    
    
	<div class="modal fade" id="delete<?php echo $i; ?>" tabindex="-1" role="dialog" aria-labelledby="edit" aria-hidden="true">
	  <div class="modal-dialog">
		<div class="modal-content">
		<form action="<?php echo e(route('category.destroy' , $category->id)); ?>" method="POST">
        <?php echo e(csrf_field()); ?>

        <input name="_method" type="hidden" value="DELETE">
		   <div class="modal-header">
		    <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>
		    <h4 class="modal-title custom_align" id="Heading">Delete this entry</h4>
		  </div>
		      <div class="modal-body">
		   
		   <div class="alert alert-danger"><span class="glyphicon glyphicon-warning-sign"></span> Are you sure you want to delete this Record?</div>
		   
		  </div>
		    <div class="modal-footer ">
		    <button type="submit" class="btn btn-success" ><span class="glyphicon glyphicon-ok-sign"></span> Yes</button>
		    <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> No</button>
		  </div>
		  </form>
	    </div>
	<!-- /.modal-content --> 
		</div>
	  <!-- /.modal-dialog --> 
	</div>

<?php  
	$i++
 ?> 
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



  </tbody>
        
</table>
             
  </div>
    
</div>

<div class="col-md-6">
	<h4><strong>Add New  Category</strong></h4>
	<form method="post" action="<?php echo e(route('category.store')); ?>">
	<?php echo e(csrf_field()); ?>

	<div class="form-group">
		<input type="text" name="name" class="form-control" placeholder="New Category" required>
		<button type="submit" class="btn btn-info" style="float: right;margin-top: 10px">Create</button>
	</div>
	</form>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>