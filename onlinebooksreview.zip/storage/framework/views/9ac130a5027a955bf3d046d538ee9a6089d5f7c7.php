Name : <?php echo e($name); ?>

Email : <?php echo e($email); ?>

Subject : <?php echo e($subject); ?>

Message : <?php echo e($content); ?>