@extends('layouts.admin_master')

@section('content')
	<div class="row">
		<div class="alert alert-info">
			<center>Welcome to Dashboard</center>
		</div>
	</div>
@endsection