Name : {{ $name }}
Email : {{ $email }}
Subject : {{ $subject }}
Message : {{ $content }}